﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class ReadTestDataFile : IReadTestDataFile
    {
        private static ReadTestDataFile obj = null;
        private ReadTestDataFile()
        { }
        public static ReadTestDataFile CreateObject()
        {
            if (obj == null)
            {
                obj = new ReadTestDataFile();
            }
            return obj;
        }
        public List<string> ReadTestData(string path)
        {
            List<string> testData = new List<string>();
            try
            {
                string[] lines;
                lines = File.ReadAllLines(path);
                foreach (string line in lines)
                {
                    if (line.Contains("how"))
                    {
                        break;
                    }
                    testData.Add(line);
                }
                return testData;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<string> ReadTestQueries(string path)
        {
            List<string> testQueries = new List<string>();
            try
            {
                string[] lines;
                lines = File.ReadAllLines(path);
                foreach (string line in lines)
                {
                    if (!line.Contains("how"))
                    {
                        continue;
                    }
                    testQueries.Add(line);
                }
                return testQueries;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
