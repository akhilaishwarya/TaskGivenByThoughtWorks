﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Task1
{
    class Program
    {
        public static void Main(string[] args)
        {
            ITestInputToDictionaryBuilder testInputToDictionaryBuilder = TestInputToDictionary.CreateObject();
            IReadTestDataFile readTestDataFile = ReadTestDataFile.CreateObject();            
            Console.Write("Please input the exact path of the test data file:");
            string path = Console.ReadLine();
            List<string> testData = readTestDataFile.ReadTestData(path);
            List<string> testQueries = readTestDataFile.ReadTestQueries(path);
            try
            {
                foreach (string input in testData)
                {
                    string[] tokens = input.Split(' ');
                    testInputToDictionaryBuilder.TestInputToDictionaryBuilder(tokens);
                }
                foreach (string input in testQueries)
                {
                    string[] tokens = input.Split(' ');
                    testInputToDictionaryBuilder.TestQueriesToDictionaryBuilder(tokens);
                }
            }
            catch (Exception)
            {
                throw new NullReferenceException();
            }
            Dictionary<string, int> TestOutputRoman = testInputToDictionaryBuilder.GetOutputDictionaryForRoman();
            Dictionary<string, double> TestOutputMetal = testInputToDictionaryBuilder.GetOutputDictionaryForMetal();
            foreach (KeyValuePair<string, int> entryForRomanNumbers in TestOutputRoman)
            {
                Console.WriteLine(entryForRomanNumbers.Key + " is " + entryForRomanNumbers.Value.ToString());
            }
            foreach (KeyValuePair<string, double> entryForMetals in TestOutputMetal)
            {
                if (entryForMetals.Key.Equals("Error in input"))
                {
                    Console.WriteLine("I have no idea what you are talking about");
                }
                else
                { 
                    Console.WriteLine(entryForMetals.Key + " is " + entryForMetals.Value.ToString() + " Credits");
                }
            }
            Console.ReadKey();
        }             
                
        

        
    }
}
