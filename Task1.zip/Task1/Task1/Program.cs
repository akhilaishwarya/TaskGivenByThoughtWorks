﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Task1
{
    class Program
    {
        public static void Main(string[] args)
        {                      
            Console.Write("Please input the exact path of the test data file:");
            string path = Console.ReadLine();            
            try
            {
                IInterGalacticUnitConvertor interGalacticUnitConvertorObject = new InterGalacticUnitConvertor();
                interGalacticUnitConvertorObject.ProcessTestDataAndTestQueries(path);
                interGalacticUnitConvertorObject.PrintOutput();
            }
            catch (Exception)
            {
                throw new NullReferenceException();
            }            
            Console.ReadKey();
        } 
    }
}
