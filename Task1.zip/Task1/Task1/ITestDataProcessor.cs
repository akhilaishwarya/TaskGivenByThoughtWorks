﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    interface ITestDataProcessor
    {
        void ProcessDataForInterGalacticDigit(string[] inputTokens,ref Dictionary<string, char> InterGalacticDigitToRomanDigitMap);
        void ProcessDataForMetals(string[] inputTokens, Dictionary<string, char> InterGalacticDigitToRomanDigitMap, ref Dictionary<string, string> InterGalacticNumberToMetalMap, ref Dictionary<string, double> MetalToItsCostMap);
    }
}
