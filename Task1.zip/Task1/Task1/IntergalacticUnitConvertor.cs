﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class InterGalacticUnitConvertor : IInterGalacticUnitConvertor
    {
        public void PrintOutput()
        {
            IProcessDataAndQueries processDataAndQueriesObject = ProcessDataAndQueries.CreateObject();
            Dictionary<string, int> outputForInterGalacticDigit = processDataAndQueriesObject.GetOutputForInterGalacticDigit();
            Dictionary<string, double> outputForMetal = processDataAndQueriesObject.GetOutputForMetal();
            foreach (KeyValuePair<string, int> entryForInterGalacticDigit in outputForInterGalacticDigit)
            {
                Console.WriteLine(entryForInterGalacticDigit.Key + " is " + entryForInterGalacticDigit.Value.ToString());
            }
            foreach (KeyValuePair<string, double> entryForMetals in outputForMetal)
            {
                if (entryForMetals.Key.Equals(ConstantValues.ErrorInInputQuery))
                {
                    Console.WriteLine(ConstantValues.NoIdeaAboutInputQuery);
                }
                else
                {
                    Console.WriteLine(entryForMetals.Key + " is " + entryForMetals.Value.ToString() + " Credits");
                }
            }
            processDataAndQueriesObject = null;
            outputForInterGalacticDigit = null;
            outputForMetal = null;
        }

        public void ProcessTestDataAndTestQueries(string path)
        {
            IProcessDataAndQueries processDataAndQueriesObject = ProcessDataAndQueries.CreateObject();
            IReadFromFile readFromFileObject = ReadFromFile.CreateObject();
            List<string> testData = null;
            List<string> testQueries = null;
            testData = readFromFileObject.ReadTestData(path);
            testQueries = readFromFileObject.ReadTestQueries(path);
            if (testData != null && testQueries != null)
            {
                foreach (string input in testData)
                {
                    string[] tokens = input.Split(ConstantValues.Space);
                    processDataAndQueriesObject.ProcessTestData(tokens);
                }
                foreach (string input in testQueries)
                {
                    string[] tokens = input.Split(ConstantValues.Space);
                    processDataAndQueriesObject.ProcessTestQueries(tokens);
                }
            }
            testData = null;
            testQueries = null;
            readFromFileObject = null;
            processDataAndQueriesObject = null;
        }
    }
}
