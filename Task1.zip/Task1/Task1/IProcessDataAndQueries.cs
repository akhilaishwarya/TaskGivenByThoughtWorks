﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    interface IProcessDataAndQueries
    {
        bool ProcessTestData(string[] inputTokens);
        bool ProcessTestQueries(string[] inputTokens);
        Dictionary<string, int> GetOutputForInterGalacticDigit();
        Dictionary<string, double> GetOutputForMetal();
    }
}
