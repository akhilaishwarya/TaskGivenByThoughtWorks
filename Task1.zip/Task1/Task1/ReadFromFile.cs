﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class ReadFromFile : IReadFromFile
    {
        private static ReadFromFile obj = null;
        private ReadFromFile()
        { }
        public static ReadFromFile CreateObject()
        {
            if (obj == null)
            {
                obj = new ReadFromFile();
            }
            return obj;
        }
        public List<string> ReadTestData(string path)
        {
            List<string> testData = new List<string>();
            try
            {
                string[] lines;
                lines = File.ReadAllLines(path);
                foreach (string line in lines)
                {
                    string upperCaseString = line.ToUpper();
                    if (upperCaseString.Contains(ConstantValues.How))
                    {
                        break;
                    }
                    testData.Add(line);
                }
                return testData;
            }
            catch (IOException)
            {
                return null;
            }
        }

        public List<string> ReadTestQueries(string path)
        {
            List<string> testQueries = new List<string>();
            try
            {
                string[] lines;
                lines = File.ReadAllLines(path);
                foreach (string line in lines)
                {
                    string upperCaseString = line.ToUpper();
                    if (!upperCaseString.Contains(ConstantValues.How))
                    {
                        continue;
                    }
                    testQueries.Add(line);
                }
                return testQueries;
            }
            catch (IOException)
            {
                return null;
            }
        }
    }
}
