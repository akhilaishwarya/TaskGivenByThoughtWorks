﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    interface IReadFromFile
    {
        List<string> ReadTestData(string path);
        List<string> ReadTestQueries(string path);
    }
}
