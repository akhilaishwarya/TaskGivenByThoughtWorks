﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class TestDataProcessor : ITestDataProcessor
    {
        private static TestDataProcessor Obj = null;
        private TestDataProcessor()
        {
        }
        public static TestDataProcessor CreateObject()
        {
            if (Obj == null)
            {
                Obj = new TestDataProcessor();
            }
            return Obj;
        }
        public void ProcessDataForInterGalacticDigit(string[] inputTokens, ref Dictionary<string, char> InterGalacticDigitToRomanDigitMap)
        {
            if (inputTokens.Length >= 2)
            {
                string interGalacticDigit = inputTokens[0];
                char romanDigit = Convert.ToChar(inputTokens[2]);
                InterGalacticDigitToRomanDigitMap.Add(interGalacticDigit, romanDigit);
            }            
        }

        public void ProcessDataForMetals(string[] inputTokens, Dictionary<string, char> InterGalacticDigitToRomanDigitMap, ref Dictionary<string, string> InterGalacticNumberToMetalMap, ref Dictionary<string, double> MetalToItsCostMap)
        {
            IStringOperations stringOperation = StringOperations.CreateObject();
            StringBuilder interGalacticNumber = new StringBuilder();
            IRomanNumberComputation romanNumberComputation = RomanNumberComputation.CreateObject();
            IValidationCheck romanNumberValidator = RomanNumberComputation.CreateObject();
            int indexOfMetal = stringOperation.GetIndexOfMetalInStringArray(inputTokens, ref interGalacticNumber);

            string metalName = inputTokens[indexOfMetal];

            string interGalacticNumberString = interGalacticNumber.ToString().Trim();

            string romanNumber = romanNumberComputation.ConvertIntergalacticNumberToRomanNumber(interGalacticNumberString, InterGalacticDigitToRomanDigitMap);
            if (romanNumberValidator.IsValidRomanNumber(romanNumber))
            {
                double creditsForMetal = Convert.ToDouble(inputTokens[indexOfMetal + 2]);

                int quantityOfMetal = romanNumberComputation.RomanToInteger(romanNumber);

                double costOfMetal = creditsForMetal / quantityOfMetal;

                InterGalacticNumberToMetalMap.Add(interGalacticNumberString, metalName);

                MetalToItsCostMap.Add(metalName, costOfMetal);
            }
        }
    }
}
