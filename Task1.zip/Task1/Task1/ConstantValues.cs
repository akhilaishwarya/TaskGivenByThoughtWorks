﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class ConstantValues
    {
        public static string How = "HOW";
        public static string NoIdeaAboutInputQuery ="I have no idea what you are talking about";
        public static string ErrorInInputQuery = "Error in input";
        public static char Space = ' ';

    }
}
