﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class ProcessDataAndQueries : IProcessDataAndQueries
    {
        private Dictionary<string, char> InterGalacticDigitToRomanDigitMap = new Dictionary<string, char>();
        private Dictionary<string, string> InterGalacticNumberToMetalMap = new Dictionary<string, string>();
        private Dictionary<string, double> MetalToItsCostMap = new Dictionary<string, double>();
        public Dictionary<string, int> OutputForInterGalacticDigit = new Dictionary<string, int>();
        public Dictionary<string, double> OutputForMetal = new Dictionary<string, double>();
        private static ProcessDataAndQueries Obj = null;
        private ProcessDataAndQueries()
        {
        }
        public static ProcessDataAndQueries CreateObject()
        {
            if (Obj == null)
            {
                Obj = new ProcessDataAndQueries();
            }
            return Obj;
        }
        public bool ProcessTestData(string[] inputTokens)
        {
            ITestDataProcessor testDataProcessorObject = TestDataProcessor.CreateObject();
            try
            {
                if (inputTokens.Length == 3)
                {
                    testDataProcessorObject.ProcessDataForInterGalacticDigit(inputTokens,ref InterGalacticDigitToRomanDigitMap);
                }
                else
                {
                    testDataProcessorObject.ProcessDataForMetals(inputTokens, InterGalacticDigitToRomanDigitMap, ref InterGalacticNumberToMetalMap, ref MetalToItsCostMap);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool ProcessTestQueries(string[] inputTokens)
        {
            ITestQueryProcessor testQueryProcessorObject = TestQueryProcessor.CreateObject();
            try
            {
                switch (inputTokens[2])
                {
                    case "is":
                        testQueryProcessorObject.ProcessQueryForInterGalacticUnit(inputTokens, ref OutputForInterGalacticDigit, InterGalacticDigitToRomanDigitMap);
                        break;
                    case "Credits":
                        testQueryProcessorObject.ProcessQueryForMetals(inputTokens, ref OutputForMetal, InterGalacticDigitToRomanDigitMap, MetalToItsCostMap);
                        break;
                    default:
                        OutputForMetal.Add(ConstantValues.ErrorInInputQuery, 0);
                        return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public Dictionary<string, int> GetOutputForInterGalacticDigit()
        {
            return OutputForInterGalacticDigit;
        }

        public Dictionary<string, double> GetOutputForMetal()
        {
            return OutputForMetal;
        }
    }
}
