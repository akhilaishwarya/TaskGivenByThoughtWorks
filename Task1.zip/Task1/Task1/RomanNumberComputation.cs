﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class RomanNumberComputation : IRomanNumberComputation, IValidationCheck
    {
        private static RomanNumberComputation obj = null;
        private RomanNumberComputation()
        { }
        public static RomanNumberComputation CreateObject()
        {
            if (obj == null)
            {
                obj = new RomanNumberComputation();
            }
            return obj;
        }
        private static Dictionary<char, int> RomanMap = new Dictionary<char, int>()
        {
            {'I', 1},
            {'V', 5},
            {'X', 10},
            {'L', 50},
            {'C', 100},
            {'D', 500},
            {'M', 1000}
        };
        public int RomanToInteger(string romanNumber)
        {
            int decimalNumber = 0;
            for (int i = 0; i < romanNumber.Length; i++)
            {
                if (i + 1 < romanNumber.Length && RomanMap[romanNumber[i]] < RomanMap[romanNumber[i + 1]])
                {
                    decimalNumber -= RomanMap[romanNumber[i]];
                }
                else
                {
                    decimalNumber += RomanMap[romanNumber[i]];
                }
            }
            return decimalNumber;
        }

        public string ConvertIntergalacticNumberToRomanNumber(string intergalacticNumber, Dictionary<string, char> IntergalacticDigitToRomanDigitMap)
        {
            StringBuilder romanNumber = new StringBuilder();
            if (!string.IsNullOrEmpty(intergalacticNumber))
            {
                string[] tokens = intergalacticNumber.Split(' ');
                foreach (string token in tokens)
                {
                    if (!string.IsNullOrEmpty(token))
                    {
                        char romanDigit = IntergalacticDigitToRomanDigitMap[token];
                        romanNumber.Append(romanDigit);
                    }
                }
            }
            return romanNumber.ToString();
        }

        private bool CheckForSubstractionRule(string romanNumber)
        {
            char[] keys = RomanMap.Keys.ToArray();
            for (int index = 1; index < romanNumber.Length; )
            {
                int indexOfPreviousDigit = GetIndexOfAChar(romanNumber[index - 1], keys);
                int indexOfCurrentDigit = GetIndexOfAChar(romanNumber[index], keys);
                if (indexOfCurrentDigit - indexOfPreviousDigit > 2)
                {
                    return false;
                }
                if (indexOfCurrentDigit > indexOfPreviousDigit)
                    index = index + 2;
                else
                    index++;
            }
            return true;
        }
        private int GetIndexOfAChar(char digit, char[] keys)
        {
            for (int index = 0; index < keys.Length; index++)
            {
                if (digit.Equals(keys[index]))
                {
                    return index;
                }
            }
            return -1;
        }

        private bool CheckForRepeatitionRule(string romanNumber)
        {
            int count = 0;
            bool isContinuous = true;
            for (int index1 = 0; index1 < romanNumber.Length; index1++)
            {
                count = 0;
                for (int index2 = index1; index2 < romanNumber.Length; index2++)
                {
                    if (isContinuous && romanNumber[index1].Equals(romanNumber[index2]))
                    {
                        isContinuous = true;
                        count++;
                    }
                    else
                    {
                        isContinuous = false;
                        count = 0;
                    }
                    if (IsValidRpeatition(romanNumber[index1], count))
                    {
                        bool isRightSequence = CheckForSmallerValueBetweenThirdAndFourthSymbols(romanNumber, index1, index2, count);
                        if (isRightSequence)
                            continue;
                        else
                            return false;
                    }
                    else
                        return false;
                }
            }
            return true;
        }
        private bool CheckForSmallerValueBetweenThirdAndFourthSymbols(string romanNumber, int index1, int index2, int count)
        {
            char digit = romanNumber[index1];
            char[] keys = RomanMap.Keys.ToArray();
            bool flag = (digit.Equals('I') || digit.Equals('X') || digit.Equals('C') || digit.Equals('M')) && count == 3 && (index2 + 1) < romanNumber.Length;
            if (flag)
            {
                char nextSymbol = romanNumber[index2 + 1];
                char currentSymbol = romanNumber[index2];
                int indexOfNextSymbol = GetIndexOfAChar(nextSymbol, keys);
                int indexOfCurrentSymbol = GetIndexOfAChar(currentSymbol, keys);
                if (indexOfCurrentSymbol < indexOfNextSymbol)
                    return false;
            }
            return true;
        }
        private bool IsValidRpeatition(char digit, int count)
        {
            if (digit.Equals('D') || digit.Equals('L') || digit.Equals('V'))
            {
                if (count > 1)
                    return false;
            }
            else
            {
                if (count > 3)
                {
                    return false;
                }
            }
            return true;
        }

        public bool IsValidRomanNumber(string romanNumber)
        {
            bool isValidRomanNumber = CheckForSubstractionRule(romanNumber);

            isValidRomanNumber = isValidRomanNumber & CheckForRepeatitionRule(romanNumber);

            return isValidRomanNumber;
        }
    }
}
