﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    interface ITestQueryProcessor
    {
        void ProcessQueryForInterGalacticUnit(string[] inputTokens, ref Dictionary<string, int> OutputForInterGalacticDigit, Dictionary<string, char> InterGalacticDigitToRomanDigitMap);
        void ProcessQueryForMetals(string[] inputTokens, ref Dictionary<string, double> OutputForMetal, Dictionary<string, char> InterGalacticDigitToRomanDigitMap, Dictionary<string, double> MetalToItsCostMap);
    }
}
