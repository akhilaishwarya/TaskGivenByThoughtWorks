﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class TestQueryProcessor : ITestQueryProcessor
    {
        private static TestQueryProcessor Obj = null;
        private TestQueryProcessor()
        {
        }
        public static TestQueryProcessor CreateObject()
        {
            if (Obj == null)
            {
                Obj = new TestQueryProcessor();
            }
            return Obj;
        }
        public void ProcessQueryForInterGalacticUnit(string[] inputTokens, ref Dictionary<string, int> OutputForInterGalacticDigit, Dictionary<string, char> InterGalacticDigitToRomanDigitMap)
        {
            IRomanNumberComputation romanNumberComputation = RomanNumberComputation.CreateObject();
            IValidationCheck romanNumberValidator = RomanNumberComputation.CreateObject();
            StringBuilder interGalacticNumber = new StringBuilder();
            for (int index = 3; index < inputTokens.Length; index++)
            {
                if (!inputTokens[index].Equals("?"))
                {
                    interGalacticNumber.Append(inputTokens[index] + " ");
                }
            }
            string interGalacticNumberString = interGalacticNumber.ToString();
            string romanNumber = romanNumberComputation.ConvertIntergalacticNumberToRomanNumber(interGalacticNumberString, InterGalacticDigitToRomanDigitMap);
            if (romanNumberValidator.IsValidRomanNumber(romanNumber))
            {
                int decimalValueOfRomanNumber = romanNumberComputation.RomanToInteger(romanNumber);
                OutputForInterGalacticDigit.Add(interGalacticNumberString, decimalValueOfRomanNumber);
            }
        }

        public void ProcessQueryForMetals(string[] inputTokens, ref Dictionary<string, double> OutputForMetal, Dictionary<string, char> InterGalacticDigitToRomanDigitMap, Dictionary<string, double> MetalToItsCostMap)
        {
            StringBuilder interGalacticNumber = new StringBuilder();
            IStringOperations stringOperation = StringOperations.CreateObject();
            IRomanNumberComputation romanNumberComputation = RomanNumberComputation.CreateObject();
            IValidationCheck romanNumberValidator = RomanNumberComputation.CreateObject();
            int indexOfCapitallatter = -1;
            for (int index = 4; index < inputTokens.Length; index++)
            {
                if (!inputTokens[index].Equals("?"))
                {
                    if (stringOperation.CheckFirstCharacterForCapital(inputTokens[index]))
                    {
                        indexOfCapitallatter = index;
                        break;
                    }
                    interGalacticNumber.Append(inputTokens[index] + " ");
                }
            }
            string interGalacticNumberString = interGalacticNumber.ToString();
            string metalName = inputTokens[indexOfCapitallatter];
            string romanNumber = romanNumberComputation.ConvertIntergalacticNumberToRomanNumber(interGalacticNumberString, InterGalacticDigitToRomanDigitMap);
            if (romanNumberValidator.IsValidRomanNumber(romanNumber))
            {
                int quantityOfMetal = romanNumberComputation.RomanToInteger(romanNumber);
                double costOfMetal = MetalToItsCostMap[metalName];
                interGalacticNumber.Append(metalName);
                OutputForMetal.Add(interGalacticNumber.ToString(), (costOfMetal * quantityOfMetal));
            }
        }
    }
}
